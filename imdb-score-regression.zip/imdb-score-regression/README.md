# 🎬 IMDb Movie Score Prediction — Regression Project

An end-to-end regression pipeline that predicts a movie's **IMDb score**
from production-era metadata — budget, cast/director popularity, genre,
critic and user engagement, and more — using the classic
[IMDb 5000 Movie Dataset](https://www.kaggle.com/datasets/carolzhangdc/imdb-5000-movie-dataset)
(5,043 movies, 28 raw features).

The full workflow — data preprocessing, EDA, feature engineering, feature
selection, model training, evaluation, and hyperparameter tuning — lives in a
single, fully-executed, step-by-step notebook.

## 📓 Notebook

➡️ [`notebooks/imdb_score_regression.ipynb`](notebooks/imdb_score_regression.ipynb)

## 🧭 Pipeline

| # | Stage | What happens |
|---|---|---|
| 1 | **Data Preprocessing** | Drop duplicates & leakage-prone identifier columns, median/mode imputation, IQR outlier capping, `has_budget_data` / `has_gross_data` missingness flags |
| 2 | **EDA** | Target distribution, correlation heatmap, categorical breakdowns (content rating, release year), genre frequency & average score by genre |
| 3 | **Feature Engineering** | `profit`, `roi`, cast/director popularity aggregates, genre count, plot-keyword richness, critic-to-user review ratio, release decade, director track record |
| 4 | **Feature Selection** | One-hot encoding with rare-category collapsing, VIF-based multicollinearity pruning, mutual-information ranking as a sanity check |
| 5 | **Model Training** | Linear Regression, Ridge, Lasso, Decision Tree, Random Forest, Gradient Boosting, XGBoost |
| 6 | **Evaluation** | RMSE / MAE / R² comparison + 3-fold cross-validation stability check on the top 3 models |
| 7 | **Hyperparameter Tuning** | `RandomizedSearchCV` (3-fold) over Random Forest, Gradient Boosting, and XGBoost |
| 8 | **Final Model** | Best tuned model selected by test-set RMSE, persisted with `joblib` |

## 🏆 Result

| Metric | Value |
|---|---|
| **Final model** | XGBoost (tuned) |
| **RMSE** | 0.810 |
| **MAE** | 0.587 |
| **R²** | 0.473 |

*(IMDb scores run 1–10, so an RMSE of ~0.81 means predictions typically land
within less than a point of the true score.)*

## 📊 Key EDA finding

`num_voted_users`, review volume, and runtime carry the strongest signal
toward IMDb score; several raw popularity metrics were highly collinear and
were pruned or replaced with engineered aggregates.

![Feature importance](images/final_feature_importance.png)

## 🗂️ Repository structure

```
imdb-score-regression/
├── data/
│   └── movie_metadata.csv          # raw IMDb 5000 dataset
├── notebooks/
│   └── imdb_score_regression.ipynb # full step-by-step pipeline
├── images/                         # all charts exported from the notebook
├── models/
│   ├── final_model.pkl             # tuned XGBoost regressor
│   ├── scaler.pkl                  # fitted StandardScaler
│   └── feature_columns.pkl         # exact training column order
├── requirements.txt
└── README.md
```

## ▶️ Reproduce it

```bash
git clone https://github.com/<your-username>/imdb-score-regression.git
cd imdb-score-regression
pip install -r requirements.txt
jupyter notebook notebooks/imdb_score_regression.ipynb
```

## 🔮 Load the saved model for inference

```python
import joblib
import pandas as pd

model = joblib.load('models/final_model.pkl')
feature_columns = joblib.load('models/feature_columns.pkl')

# new_data must be a DataFrame preprocessed identically to the notebook
# (same engineered features, same one-hot columns, in feature_columns order)
new_data = new_data.reindex(columns=feature_columns, fill_value=0)
predicted_score = model.predict(new_data)
```

## 🛠️ Tech stack

`pandas` · `numpy` · `scikit-learn` · `xgboost` · `statsmodels` · `matplotlib` · `seaborn` · `joblib`

## 📌 Notes / limitations

- R² of ~0.47 reflects a genuinely hard problem: IMDb score is a crowd
  opinion metric influenced by factors outside this dataset (marketing,
  timing, cultural context, critical reception after release).
- `budget`/`gross` contain known currency-scraping errors in the source
  dataset, handled here via IQR capping rather than deletion.
- This is a portfolio / teaching artifact — see `notebooks/imdb_score_regression.ipynb`
  for full methodology notes at each step.

---
*Built by Sirisha*
